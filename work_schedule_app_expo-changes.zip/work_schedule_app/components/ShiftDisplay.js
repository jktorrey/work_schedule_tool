// src/components/ShiftDisplay.js
const ShiftDisplay = ({ shift, previousDayShift, nextDayShift, selectedDate, isDarkMode }) => {
  const getShiftColor = (shift) => {
    switch (shift) {
      case 'Straight':
        return 'bg-purple-600';
      case 'Mid':
        return 'bg-indigo-600';
      case 'Break':
        return 'bg-emerald-600';
      case 'Day':
        return 'bg-amber-500';
      default:
        return 'bg-gray-600';
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center">
      {shift ? (
        <div className="text-center">
          <div className="flex items-center justify-center gap-4 mb-3">
            {/* Previous Day */}
            <div
              className={`w-16 h-16 rounded-full ${getShiftColor(previousDayShift)} flex items-center justify-center shadow-md opacity-60`}
            >
              <span className="text-white text-sm">{previousDayShift}</span>
            </div>

            {/* Current Day */}
            <div
              className={`w-32 h-32 rounded-full ${getShiftColor(shift)} flex items-center justify-center shadow-lg`}
            >
              <span className="text-white text-3xl">{shift}</span>
            </div>

            {/* Next Day */}
            <div
              className={`w-16 h-16 rounded-full ${getShiftColor(nextDayShift)} flex items-center justify-center shadow-md opacity-60`}
            >
              <span className="text-white text-sm">{nextDayShift}</span>
            </div>
          </div>
          <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} text-lg`}>
            {new Date(selectedDate).toLocaleDateString('en-US', { weekday: 'long' })} - {SHIFT_DESCRIPTIONS[shift]}
          </p>
        </div>
      ) : (
        <div className="text-center">
          <div className={`w-32 h-32 rounded-full ${isDarkMode ? 'bg-gray-800' : 'bg-gray-200'} flex items-center justify-center mb-3`}>
            <span className={`${isDarkMode ? 'text-gray-600' : 'text-gray-400'} text-3xl`}>--</span>
          </div>
          <p className={`${isDarkMode ? 'text-gray-500' : 'text-gray-600'} text-base`}>
            Select a date
          </p>
        </div>
      )}
    </div>
  );
};

export default ShiftDisplay;
