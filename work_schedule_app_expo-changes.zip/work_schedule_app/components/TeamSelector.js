// src/components/TeamSelector.js
const TeamSelector = ({ selectedTeam, setSelectedTeam, isDarkMode }) => {
  return (
    <div className="mb-6">
      <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} text-base mb-2 text-center`}>Team</p>
      <div className="grid grid-cols-4 gap-2">
        {[1, 2, 3, 4].map((team) => (
          <button
            key={team}
            onClick={() => setSelectedTeam(team)}
            className={`h-12 rounded-2xl transition-all flex items-center justify-center text-lg ${
              selectedTeam === team
                ? 'bg-blue-600 text-white scale-105'
                : isDarkMode
                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {team}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TeamSelector;
