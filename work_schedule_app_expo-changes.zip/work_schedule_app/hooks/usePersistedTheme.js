import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';  // Import AsyncStorage from Expo

const usePersistedTheme = (defaultTheme) => {
  const [isDarkMode, setIsDarkMode] = useState(defaultTheme);

  useEffect(() => {
    const loadTheme = async () => {
      try {
        const storedTheme = await AsyncStorage.getItem('isDarkMode');
        if (storedTheme !== null) {
          setIsDarkMode(JSON.parse(storedTheme));  // If a theme is found, update state
        }
      } catch (error) {
        console.error('Failed to load theme from AsyncStorage:', error);
      }
    };

    loadTheme();
  }, []);

  useEffect(() => {
    const saveTheme = async () => {
      try {
        await AsyncStorage.setItem('isDarkMode', JSON.stringify(isDarkMode));
      } catch (error) {
        console.error('Failed to save theme to AsyncStorage:', error);
      }
    };

    saveTheme();
  }, [isDarkMode]);

  const toggleTheme = () => {
    setIsDarkMode((prev) => !prev);
  };

  return { isDarkMode, toggleTheme };
};

export { usePersistedTheme };
