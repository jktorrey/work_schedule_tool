// src/constants/rotationSchedule.js
export const ROTATION_SCHEDULE = [
  'Straight', 'Straight', 'Straight', 'Straight', 'Straight', 'Straight', 'Straight',
  'Mid', 'Mid', 'Mid', 'Mid', 'Break', 'Break', 'Break',
  'Mid', 'Mid', 'Mid', 'Break', 'Break', 'Break', 'Break',
  'Day', 'Day', 'Day', 'Break', 'Break', 'Break', 'Break',
  'Day', 'Day', 'Day', 'Day', 'Break', 'Break', 'Break',
  'Break', 'Break', 'Break', 'Day', 'Day', 'Day', 'Day',
  'Break', 'Break', 'Break', 'Break', 'Day', 'Day', 'Day',
  'Break', 'Break', 'Break', 'Mid', 'Mid', 'Mid',
  'Break', 'Break', 'Break', 'Mid', 'Mid', 'Mid', 'Mid',
  'Straight', 'Straight', 'Straight', 'Straight', 'Straight', 'Straight', 'Straight'
];
