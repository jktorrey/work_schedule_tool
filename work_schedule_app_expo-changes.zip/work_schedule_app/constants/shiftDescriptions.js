// src/constants/shiftDescriptions.js
export const SHIFT_DESCRIPTIONS = {
  'Straight': 'Duty Hours: Flexible (weekends/holidays permitted only when covering)',
  'Mid': 'Duty Hours: 1700-0500',
  'Break': 'Duty Hours: None',
  'Day': 'Duty Hours: 0500-1700',
};
