// src/App.js
import React, { useState, useEffect, useMemo } from 'react';
import { Dimensions, Text, View } from 'react-native'; // Import View and Text from React Native
import { DateTimePicker } from '@react-native-community/datetimepicker';
import { usePersistedTheme } from './hooks/usePersistedTheme';
import ThemeToggle from './components/ThemeToggle';
import TeamSelector from './components/TeamSelector';
import ShiftDisplay from './components/ShiftDisplay';
import { ROTATION_SCHEDULE } from './constants/rotationSchedule';
import { SHIFT_DESCRIPTIONS } from './constants/shiftDescriptions';

// Utility function to get dimensions safely
const getDeviceDimensions = () => {
  if (typeof Dimensions !== 'undefined' && Dimensions.get) {
    const { width, height } = Dimensions.get('window');
    return { width, height };
  }
  if (typeof window !== 'undefined' && window.innerWidth) {
    return { width: window.innerWidth, height: window.innerHeight };
  }
  return { width: 0, height: 0 };
};

// Check if device is likely an Apple Watch (with screen smaller than 400px)
const isAppleWatch = () => {
  const { width, height } = getDeviceDimensions();
  return Math.min(width, height) < 400;
};

const TEAM_START_DATES = {
  1: new Date('2025-02-02'),
  2: new Date('2025-02-16'),
  3: new Date('2025-03-02'),
  4: new Date('2025-01-05'),
};

// Get shift for a team and date
function getShiftForTeamAndDate(team, date) {
  const teamStartDate = TEAM_START_DATES[team];
  const daysDiff = Math.floor((date.getTime() - teamStartDate.getTime()) / (1000 * 60 * 60 * 24));
  const rotationLength = 70; // 10 weeks * 7 days
  const dayInRotation = ((daysDiff % rotationLength) + rotationLength) % rotationLength;
  
  return ROTATION_SCHEDULE[dayInRotation];
}

export default function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  
  // Use the custom hook for theme persistence
  const { isDarkMode, toggleTheme } = usePersistedTheme(true); // Default to dark mode if not set

  const shift = useMemo(() => selectedTeam ? getShiftForTeamAndDate(selectedTeam, selectedDate) : null, [selectedTeam, selectedDate]);
  
  const fetchShift = () => {
    setIsLoading(true);
    // Simulating fetching data
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  useEffect(() => {
    if (selectedTeam) {
      fetchShift();
    }
  }, [selectedTeam, selectedDate]);

  const previousDayShift = selectedTeam ? getShiftForTeamAndDate(selectedTeam, new Date(selectedDate.setDate(selectedDate.getDate() - 1))) : null;
  const nextDayShift = selectedTeam ? getShiftForTeamAndDate(selectedTeam, new Date(selectedDate.setDate(selectedDate.getDate() + 1))) : null;

  return (
    <View className={`min-h-screen ${isDarkMode ? 'bg-black' : 'bg-gray-100'} flex items-center justify-center p-4`}>
      {/* Main Container */}
      <View className={`relative ${isAppleWatch() ? 'w-[300px] h-[350px]' : 'w-[390px] h-[450px]'} ${isDarkMode ? 'bg-gradient-to-br from-gray-900 to-black border-gray-800' : 'bg-gradient-to-br from-gray-200 to-white border-gray-300'} rounded-[60px] border-8 shadow-2xl overflow-hidden`}>
        {/* Screen */}
        <View className={`w-full h-full ${isDarkMode ? 'bg-black' : 'bg-white'} p-6 flex flex-col`}>
          {/* Header */}
          <View className="text-center mb-6 relative">
            {/* Replace h1 with Text */}
            <Text className={`${isAppleWatch() ? 'text-xl' : 'text-2xl'} ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-1`}>
              Shift Happens
            </Text>
            <Text className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} text-base`}>Select team & date</Text>
            <ThemeToggle isDarkMode={isDarkMode} toggleTheme={toggleTheme} />
          </View>

          {/* Team Selection */}
          <TeamSelector selectedTeam={selectedTeam} setSelectedTeam={setSelectedTeam} isDarkMode={isDarkMode} />

          {/* Date Selection */}
          <View className="mb-3">
            <Text className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} text-base mb-2 text-center`}>Date</Text>
            <button onClick={() => setShowDatePicker(true)} className={`w-full h-10 ${isDarkMode ? 'bg-gray-800 hover:bg-gray-700 text-white' : 'bg-gray-200 hover:bg-gray-300 text-gray-900'} rounded-2xl flex items-center justify-center gap-2 transition-colors`}>
              <span className="text-base">{selectedDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
            </button>
            {showDatePicker && (
              <DateTimePicker
                value={selectedDate}
                mode="date"
                display="default"
                onChange={(event, date) => {
                  if (date) {
                    setSelectedDate(date);
                  }
                  setShowDatePicker(false);
                }}
              />
            )}
          </View>

          {/* Shift Display */}
          <ShiftDisplay 
            shift={shift} 
            previousDayShift={previousDayShift} 
            nextDayShift={nextDayShift} 
            selectedDate={selectedDate} 
            isDarkMode={isDarkMode} 
          />
        </View>
      </View>
    </View>
  );
}
